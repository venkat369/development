module.exports = {
  extends: 'standard'
}