# Pixelcompare - Vanilla JS image comparison

Options

Option | Description | Type | Default
------ | ------ | ------ | ------
`container` | Container can be `id` or `class` | String, *Required* | 'undefined'
`orientation` | Orientation of the before and after images. Can be `vertical` or `horizontal` | String | `horizontal`
`overlay` | Slider overlay | Boolean | `false`
`hover` | Move slider on mouse hover | Boolean | `false`
